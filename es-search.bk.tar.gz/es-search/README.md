# install
~~~ bash
composer require "elasticsearch/elasticsearch:~7.0"
~~~
